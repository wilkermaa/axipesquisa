# axipesquisa v2.0.0: Grok Web

Criar skill em grok.com; se o ZIP não for aceito, usar SKILL.md avulso.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
