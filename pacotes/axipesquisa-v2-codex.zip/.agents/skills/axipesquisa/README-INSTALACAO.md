# axipesquisa v2.0.0: Codex

Extrair na raiz do projeto ou instalar em ~/.agents/skills/axipesquisa.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
