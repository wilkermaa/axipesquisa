# axipesquisa v2.0.0: Grok Build CLI

Extrair na raiz do projeto ou instalar em ~/.grok/skills/axipesquisa.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
