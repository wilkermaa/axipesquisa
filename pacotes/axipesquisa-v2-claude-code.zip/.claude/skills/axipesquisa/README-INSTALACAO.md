# axipesquisa v2.0.0: Claude Code

Extrair na raiz do projeto ou instalar em ~/.claude/skills/axipesquisa.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
