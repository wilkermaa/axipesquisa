# axipesquisa v2.0.0: Antigravity

Extrair na raiz do workspace; global em ~/.gemini/config/skills/axipesquisa.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
