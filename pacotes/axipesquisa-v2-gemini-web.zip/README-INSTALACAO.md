# axipesquisa v2.0.0: Gemini Web

Personalizar > Habilidades > Criar > Fazer upload. ZIP com SKILL.md na raiz.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
