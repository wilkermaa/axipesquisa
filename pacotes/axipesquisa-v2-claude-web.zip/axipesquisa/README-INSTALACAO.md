# axipesquisa v2.0.0: Claude Web

Personalizar > Skills > Carregar um skill; ZIP com pasta axipesquisa.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
