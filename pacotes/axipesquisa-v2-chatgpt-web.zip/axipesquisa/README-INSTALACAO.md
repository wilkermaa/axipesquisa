# axipesquisa v2.0.0: ChatGPT Web

Importar como skill em Plugins > Habilidades (apenas contas elegíveis); alternativa instruções personalizadas.

Consulte o guia completo incluído no pacote de distribuição e os arquivos `references/` para fundamentos e exemplos.
